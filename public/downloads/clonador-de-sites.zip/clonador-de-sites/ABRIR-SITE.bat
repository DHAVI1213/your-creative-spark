@echo off
title Copia do site
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor.ps1"
