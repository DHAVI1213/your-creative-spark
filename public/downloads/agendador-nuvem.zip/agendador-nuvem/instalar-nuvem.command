#!/bin/bash
# Mac/Linux: dê dois cliques (Mac) ou rode ./instalar-nuvem.command no terminal.
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "O Node.js não está instalado. Baixe a versão LTS em https://nodejs.org e rode de novo."
  read -r -p "Enter para sair"
  exit 1
fi
[ -d node_modules ] || npm install
node setup.js
read -r -p "Enter para sair"
