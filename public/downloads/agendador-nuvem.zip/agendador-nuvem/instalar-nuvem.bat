@echo off
chcp 65001 >nul
title Instalar o servidor gratis do Agendador (Cloudflare)
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  O Node.js nao esta instalado. Baixe a versao LTS em https://nodejs.org , instale e rode de novo.
  pause
  exit /b 1
)

if not exist node_modules (
  echo.
  echo  Instalando a ferramenta da Cloudflare ^(so na primeira vez^)...
  call npm install
)

node setup.js
echo.
pause
