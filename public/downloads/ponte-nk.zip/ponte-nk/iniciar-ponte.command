#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then echo "Instale o Node.js LTS em https://nodejs.org e rode de novo."; read -r -p "Enter para sair"; exit 1; fi
[ -d node_modules ] || npm install
node iniciar-ponte.js
