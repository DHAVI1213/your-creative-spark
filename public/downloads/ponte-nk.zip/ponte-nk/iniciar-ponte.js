// Ponte NK: roda no seu PC e faz o papel do "Editor em Massa" para a extensão Minerador Viral.
// - A extensão manda os vídeos escolhidos; a ponte baixa (Instagram direto; TikTok e YouTube pelo yt-dlp)
//   e guarda em Downloads/Minerador.
// - O site NK Software (Editor em Massa e Cortes Virais) busca esses vídeos aqui, com o código da ponte.
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { criarPonte } = require('./minerador-ponte');

let ffmpeg = null;
try {
  ffmpeg = require('ffmpeg-static');
} catch (_) {}

const PASTA = path.join(os.homedir(), 'Downloads', 'Minerador');
const ARQ_CODIGO = path.join(__dirname, 'codigo.txt');
let codigo = '';
try {
  codigo = fs.readFileSync(ARQ_CODIGO, 'utf8').trim();
} catch (_) {}
if (!/^[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(codigo)) {
  const a = crypto.randomBytes(8).toString('hex').toUpperCase().replace(/[^A-Z0-9]/g, '');
  codigo = `${a.slice(0, 4)}-${a.slice(4, 8)}`;
  fs.writeFileSync(ARQ_CODIGO, codigo);
}

const recebidos = []; // { id, nome, caminho, destino, perfil, plataforma, quando, tamanho }
function guardar(arquivos, destino, job) {
  for (const caminho of arquivos) {
    let tamanho = 0;
    try {
      tamanho = fs.statSync(caminho).size;
    } catch (_) {}
    recebidos.push({ id: crypto.randomUUID(), nome: path.basename(caminho), caminho, destino, perfil: job.perfil, plataforma: job.plataforma, quando: Date.now(), tamanho });
    console.log(`  ✓ ${path.basename(caminho)} pronto para o site (${destino === 'cortes' ? 'Cortes Virais' : 'mesa do Editor'})`);
  }
  while (recebidos.length > 300) recebidos.shift();
}

const CORS = (origem) => ({
  'Access-Control-Allow-Origin': origem || '*',
  'Access-Control-Allow-Headers': 'X-NK-Codigo, Content-Type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Private-Network': 'true',
  Vary: 'Origin'
});

function site(req, res) {
  const origem = req.headers.origin || '';
  const h = CORS(origem);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, h);
    return res.end();
  }
  const json = (code, data) => {
    res.writeHead(code, { ...h, 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(data));
  };
  if (String(req.headers['x-nk-codigo'] || '').toUpperCase() !== codigo) return json(401, { ok: false, erro: 'Código da ponte errado. Veja o código na janela da Ponte NK.' });
  const url = new URL(req.url, 'http://127.0.0.1');
  if (req.method === 'GET' && url.pathname === '/site/saude') return json(200, { ok: true, app: 'ponte-nk', pasta: PASTA });
  if (req.method === 'GET' && url.pathname === '/site/recebidos') {
    return json(200, { ok: true, itens: recebidos.filter((r) => fs.existsSync(r.caminho)).map(({ caminho, ...r }) => r) });
  }
  const m = url.pathname.match(/^\/site\/(arquivo|esquecer)\/([\w-]+)$/);
  const r = m && recebidos.find((x) => x.id === m[2]);
  if (m && !r) return json(404, { ok: false, erro: 'Arquivo não encontrado' });
  if (m && m[1] === 'esquecer' && req.method === 'POST') {
    recebidos.splice(recebidos.indexOf(r), 1);
    return json(200, { ok: true });
  }
  if (m && m[1] === 'arquivo' && req.method === 'GET') {
    let st;
    try {
      st = fs.statSync(r.caminho);
    } catch (_) {
      return json(404, { ok: false, erro: 'O arquivo foi apagado da pasta' });
    }
    res.writeHead(200, { ...h, 'Content-Type': /\.mp3$/i.test(r.caminho) ? 'audio/mpeg' : 'video/mp4', 'Content-Length': st.size });
    return fs.createReadStream(r.caminho).pipe(res);
  }
  return json(404, { ok: false, erro: 'Rota não encontrada' });
}

fs.mkdirSync(PASTA, { recursive: true });
criarPonte({
  porta: 47811,
  pastaBase: PASTA,
  ffmpeg,
  binDir: path.join(__dirname, 'bin'),
  aoImportar: (arquivos, job) => guardar(arquivos, 'mesa', job),
  aoCortes: (arquivos, job) => guardar(arquivos, 'cortes', job),
  log: (m) => console.log('  ' + m),
  site
})
  .iniciar()
  .then((ok) => {
    console.log('');
    console.log('  ==============================================');
    console.log('   PONTE NK · Minerador Viral ↔ NK Software');
    console.log('  ==============================================');
    if (!ok) {
      console.log('  ✗ Não consegui abrir a porta 47811. Ela já está aberta em outra janela? Feche a outra e abra de novo.');
      return;
    }
    console.log('  ✓ Ponte ligada. Deixe esta janela aberta enquanto usa o Minerador Viral.');
    console.log('');
    console.log(`  CÓDIGO DA PONTE (cole no site, uma vez só):  ${codigo}`);
    console.log('');
    console.log(`  Os vídeos baixados ficam em: ${PASTA}`);
    console.log('');
  });
